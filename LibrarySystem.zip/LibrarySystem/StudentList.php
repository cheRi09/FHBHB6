<?php 
require_once 'Connection.php';
require_once 'Authentication.php'; 
require_once 'Header.php';
?>				
<link rel="stylesheet" href="css/StudentList.css">
				<table>
				<caption>STUDENT LIST</caption>
					<thead>
						<tr>							
							<th scope="col">Student ID</th>
							<th scope="col">Student Name</th>
							<th scope="col">Year</th>
							<th scope="col">Section</th>
							<th scope="col">Department</th>
							<th scope="col">Option</th>
						</tr>
					</thead>
				<?php
				
				include "Connection.php";
				
				$records = mysqli_query($connect, "SELECT * FROM studentlist");
				
				while($data = mysqli_fetch_array($records))
				{
					?>
					<tr>
					<td><?php echo $data['studentid']; ?></td>
					<td><?php echo $data['studentname']; ?></td>
					<td><?php echo $data['year']; ?></td>
					<td><?php echo $data['section']; ?></td>
					<td><?php echo $data['department']; ?></td>
					<td><div class="btn-group">
	    <a href="RemoveStudent.php?id=<?php echo $data['studentid'];?>" class="refe">Remove</a>    
	</div>
	</td>
				</tr>
				<?php
				}
				?>
				</table>

			</div>
		</div>	
	</div>
</div>