<?php
require_once 'Connection.php';
require_once 'Authentication.php';
require 'Header.php'
?>
<link rel="stylesheet" href="css/DashboardDesign.css">
<?php 

$sql = "SELECT * FROM bookslist WHERE bookid";
$query = $connect->query($sql);
$countBooks = $query->num_rows;

$sql = "SELECT * FROM borrowerslist WHERE studentid";
$query = $connect->query($sql);
$countStudents = $query->num_rows;

$sql = "SELECT * FROM studentlist WHERE studentid";
$query = $connect->query($sql);
$countRegisteredS = $query->num_rows;

$connect->close();

?>
<!-- Page content -->
<div class="main">
	<div class="container">
  <div class="panel">
    <button class="btn"><a href="BookPage.php" class="refe"><h2>Books</a></h2><h1><?php echo $countBooks; ?></h1></button>
  </div>
  </div>
  <div class="container">
   <div class="pane2">
    <button class="btn"><a href="BorrowersPage.php" class="refe"><h2>Borrowed Books</h2></a><h1><?php echo $countStudents; ?></h1></button>
  </div>
  </div>
  <div class="container">
   <div class="pane3">
    <button class="btn"><a href="StudentList.php" class="refe"><h2>Registered Students</h2></a><h1><?php echo $countRegisteredS; ?></h1></button>
  </div>
  </div>
</div>


