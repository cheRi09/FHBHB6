<?php
$servername="localhost:3306";
$username="root";
$password="J@n122014";
$dbname="library_system";
//check connection
$connect = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno())
{
     echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>