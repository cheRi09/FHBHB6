<?php 	
include 'Connection.php';
require_once 'Authentication.php';


$studentid = $_GET['id'];
$del = mysqli_query($connect,"DELETE FROM borrowerslist WHERE studentid=$studentid");

if($del)
{
	echo "<script>alert('SUCCESSFULLY DELETED')</script>";
	mysqli_close($connect);
	exit;
}
else
{
	echo "ERROR DELETING";
	
} // /if $_POST