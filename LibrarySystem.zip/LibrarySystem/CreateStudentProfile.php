<link rel="stylesheet" href="css/CreateStudentProfile.css">
<?php
    require('Connection.php');
	require_once 'Authentication.php';
	require_once 'Header.php';
    if (isset($_REQUEST['studentid'])) {
        // removes backslashes
        $studentid = stripslashes($_REQUEST['studentid']);
        //escapes special characters in a string
        $studentid = mysqli_real_escape_string($connect, $studentid);
        $studentname = stripslashes($_REQUEST['studentname']);
        $studentname = mysqli_real_escape_string($connect, $studentname);
		$department = stripslashes($_REQUEST['department']);
        $department = mysqli_real_escape_string($connect, $department);
		$year = stripslashes($_REQUEST['year']);
        $year = mysqli_real_escape_string($connect, $year);
		$section = stripslashes($_REQUEST['section']);
        $section = mysqli_real_escape_string($connect, $section);
        $query    = "INSERT INTO `studentlist` (studentid, studentname, department, year, section) VALUES ('$studentid', '$studentname', '$department', '$year', '$section')";
        $result   = mysqli_query($connect, $query);
        if ($result) {
            echo "<div class='form'>
                  <h3>You are registered successfully.</h3><br/>
                  <p class='link'>Click here to <a href='SignIn.php'>Login</a></p>
                  </div>";
        } else {
            echo "<div class='form'>
                  <h3>Required fields are missing.</h3><br/>
                  <p class='link'>Click here to <a href='SignUp.php'>registration</a> again.</p>
                  </div>";
        }
    } else {
?>
    <form class="form" method="post">
        <input type="text" name="studentid" placeholder="Student Id" required />
        <input type="text" name="studentname" placeholder="Student Name" required>
		<select id="department" name="department" required>
				      	<option value="">Select Department</option>
				      	<option value="BSIT">Bachelor of Science and Information Technology</option>
				      	<option value="BSED">Bachelor of Education</option>
						<option value="BSAE">Bachelor of Science and Agricultural Entrepreneurship</option>
		</select>
		<select id="year" name="year" class="year" required>
				      	<option value="">Select Year</option>
				      	<option value="1ST">1st Year</option>
				      	<option value="2ND">2nd Year</option>
						<option value="3RD">3rd Year</option>
						<option value="4TH">4th Year</option>
		</select>
		<input type="text" name="section" placeholder="Section" required />
		
        <button type="submit">Save</button>
    </form>
<?php
    }
?>
</body>
</html>
