<?php 
require_once 'Authentication.php'; 
require_once 'Connection.php'; 

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {	
	$bookname = $_POST['bookname'];
  $author = $_POST['author'];
  $genre = $_POST['genre'];
  $dateget = $_POST['dateget'];
  $status = $_POST['status'];
  

	$sql = "INSERT INTO bookslist (bookname, author, genre, dateget, status) VALUES ('$bookname', '$author', '$genre', '$dateget', '$status')";

	if($connect->query($sql) === TRUE) 
	{
		echo "<script>alert('SUCCESSFULLY ADDED')</script>";

	} 
	else 
	{
		echo "<script>alert('ERROR WHILE ADDING')</script>";
	}
	 

	$connect->close();
} // /if $_POST
?>