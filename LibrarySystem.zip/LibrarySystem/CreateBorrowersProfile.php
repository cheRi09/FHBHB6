<?php  
require_once 'Header.php';
?>
<link rel="stylesheet" href="css/CreateBorrowersProfile.css">
<?php
    require('Connection.php');
    // When form submitted, insert values into the database.
    if (isset($_REQUEST['studentid'])) 
	{
        // removes backslashes
        $studentid = stripslashes($_REQUEST['studentid']);
        //escapes special characters in a string
        $studentid = mysqli_real_escape_string($connect, $studentid);
        $studentname = stripslashes($_REQUEST['studentname']);
        $studentname = mysqli_real_escape_string($connect, $studentname);
		$year = stripslashes($_REQUEST['year']);
        $year = mysqli_real_escape_string($connect, $year);
		$section = stripslashes($_REQUEST['section']);
        $section = mysqli_real_escape_string($connect, $section);
		$department = stripslashes($_REQUEST['department']);
        $department = mysqli_real_escape_string($connect, $department);
		$book = stripslashes($_REQUEST['book']);
        $book = mysqli_real_escape_string($connect, $book);
		$dateget = stripslashes($_REQUEST['dateget']);
        $dateget = mysqli_real_escape_string($connect, $dateget);
		$dateretrieve = stripslashes($_REQUEST['dateretrieve']);
        $dateretrieve = mysqli_real_escape_string($connect, $dateretrieve);
		$status = stripslashes($_REQUEST['status']);
        $status = mysqli_real_escape_string($connect, $status);
		
        $query    = "INSERT INTO `borrowerslist` (studentid, studentname, year, section, department, book, dateget, dateretrieve, status) VALUES ('$studentid', '$studentname', '$year', '$section', '$department', '$book','$dateget','$dateretrieve','$status')";
        $result   = mysqli_query($connect, $query);
        if ($result) 
		{
            echo "<script>alert('SUCCESSFULLY ADDED')</script>"; 
        } 
		else 
		{
            echo "<script>alert('ERROR WHILE ADDING')</script>"; 
        }
    } 
	else 
	{
	?>
	<div class="center">
<div class="title1">
    	<form class="form" action="" method="POST">
		  <div class="input-group">
	        	<input type="text" id="studentid" name="studentid" placeholder="Student ID" autocomplete="off"></input>
				</div>
				<button>Search</button>
				 <div class="input-group">
				<input type="text" id="studentname" name="studentname" placeholder="Student Name" autocomplete="off"/>
				</div>
				 <div class="input-group">
				<input type="text" id="year" name="year" placeholder="Year" autocomplete="off"/>
				</div>
				 <div class="input-group">
				<input type="text" id="section" name="section" placeholder="Section" autocomplete="off"/>
				</div>
				  <div class="input-group">
				<input type="text" id="department" name="department" placeholder="Department" autocomplete="off"/>
				</div>
				 <div class="input-group">
				<input id="book" name="book" placeholder="Book" type="text"/>
				</div>
				<button>Search</button>
				<div class="input-group">
				<label class="label1">Date Get: </label><input id="dateget" name="dateget" type="date"/>
				<label class="label2">Date Retrieve: </label><input id="dateretrieve" name="dateretrieve" type="date"/>
				</div>
				<div class="input-group">
				<select id="status" name="status">
				      	<option value="">Select Status</option>
				      	<option value="Available">Available</option>
				      	<option value="Not Available">Not Available</option>
				</select>
			</div>
	        <button type="submit">Save Changes</button>
			<button href="Dashboard.php">Back</button>
     	</form>
		<?php 
	}
	?>