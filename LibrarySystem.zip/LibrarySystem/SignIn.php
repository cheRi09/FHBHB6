<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>LIBRARY MANAGEMENT SYSTEM</title>
	<link rel="stylesheet" href="css/SignIn.css">
</head>
<body>
<?php
    require('Connection.php');
    session_start();
    // When form submitted, check and create user session.
    if (isset($_POST['username'])) 
	{
        $username = stripslashes($_REQUEST['username']);    // removes backslashes
        $username = mysqli_real_escape_string($connect, $username);
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($connect, $password);
        // Check user is exist in the database
        $query    = "SELECT * FROM `admin` WHERE username='$username' AND password='$password'";
        $result = mysqli_query($connect, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        if ($rows == 1) 
		{
            $_SESSION['username'] = $username;
            // Redirect to user dashboard page
            header("Location: BookPage.php");
        } else 
			
		{
            echo "<script>alert('INCORRECT USERNAME OR PASSWORD')</script>";
			echo "<script>window.open('SignIn.php','_Self')</script>";
        }
    }
?>
<div class="center">
<div class="title1">	
    <form class="form" method="post" name="login" id="form">
	<h1 class="title">SIGN IN</h1>
		<div class="input-group">
		<i class="fas fa-user"></i>
        <input type="text" class="login-input" name="username" placeholder="USERNAME" autofocus="true" required/>
		</div>
		<div class="input-group">
        <i class="fas fa-lock"></i>
        <input type="password" class="login-input" name="password" placeholder="PASSWORD" required/>
		</div>
        <input type="submit" value="SIGN IN" name="submit" class="btn"/>
  </form>
</div>
</div>
</body>
</html>