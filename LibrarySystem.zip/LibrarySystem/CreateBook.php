<?php  
require_once 'Header.php';
?>
<link rel="stylesheet" href="css/CreateBook.css">
<?php
    require('Connection.php');
    // When form submitted, insert values into the database.
    if (isset($_REQUEST['bookname'])) 
	{
        // removes backslashes
        $bookname = stripslashes($_REQUEST['bookname']);
        //escapes special characters in a string
        $bookname = mysqli_real_escape_string($connect, $bookname);
        $author = stripslashes($_REQUEST['author']);
        $author = mysqli_real_escape_string($connect, $author);
		$genre = stripslashes($_REQUEST['genre']);
        $genre = mysqli_real_escape_string($connect, $genre);
		$dateget = stripslashes($_REQUEST['dateget']);
        $dateget = mysqli_real_escape_string($connect, $dateget);
		$status = stripslashes($_REQUEST['status']);
        $status = mysqli_real_escape_string($connect, $status);
		
        $query    = "INSERT INTO `bookslist` (bookname, author, genre, dateget, status) VALUES ('$bookname', '$author', '$genre', '$dateget', '$status')";
        $result   = mysqli_query($connect, $query);
        if ($result) 
		{
            echo "<script>alert('SUCCESSFULLY ADDED')</script>"; 
        } 
		else 
		{
            echo "<script>alert('ERROR WHILE ADDING')</script>"; 
        }
    } 
	else 
	{
	?>
<div class="center">
<div class="title1">
    	<form class="form" action="" method="POST">
		<div class="input-group">
				<input type="text" id="bookname" name="bookname" autocomplete="off" placeholder="Book Name" required/>
				</div>
				<div class="input-group">
				<input type="text" id="author" name="author" autocomplete="off" placeholder="Author" required/>
				</div>
				<div class="input-group">
				<input type="text" id="genre" name="genre" autocomplete="off" placeholder="Genre" required/>
				</div>
				<div class="date-group">
				<input id="dateget" name="dateget" type="date" placeholder="Date Get" required/>
				</div>
				<div class="select-group">
				<select id="status" name="status" placeholder="Status" required>
				      	<option value="">Select Status</option>
				      	<option value="Available">Available</option>
				      	<option value="Not Available">Not Available</option>
				</select>
			</div>
	        <button type="submit">Save Changes</button>
			<button type="submit" href="BookPage.php">Back</button>
     	</form>
		<?php
	}
		?>
</div>
</div>