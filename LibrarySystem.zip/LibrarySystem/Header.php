<?php 
require_once 'Authentication.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>LIBRARY MANAGEMENT SYSTEM</title>
	<link rel="stylesheet" href="css/Header.css">
</head>
<body>
<header>
<div class="navbar">
            <nav>
                <ul>
				<p><h1>WELCOME! ADMIN</h1></p>
				<p><h1><?php echo $_SESSION['username']; ?></h1></p>
                    <li><a href="Dashboard.php">Dashboard</a></li>
                    <li><a href="CreateBook.php">Register Book</a></li>
                    <li><a href="CreateBorrowersProfile.php">Register Borrowed Book</a></li>
                    <li><a href="CreateStudentProfile.php">Register Student</a></li>
                    <li><a href="#">Other Information</a></li>
					<li><a href="SignOut.php">Log Out</a></li>
                </ul>
            </nav>
</div>
</header>