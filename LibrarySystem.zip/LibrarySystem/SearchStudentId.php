<?php
    require('Connection.php');
	
	$sql = "SELECT studentid FROM studentlist";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
  }
} else {
  echo "0 results";
}
$conn->close();
?>