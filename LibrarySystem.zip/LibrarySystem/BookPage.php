<?php  
require_once 'Connection.php';
require_once 'Authentication.php';
require_once 'Header.php';
?>
<link rel="stylesheet" href="css/BookPage.css">
<div>
				<table>
				<caption>BOOKS LIST</caption>
					<thead>
						<tr>							
							<th scope="col">Book Id</th>
							<th scope="col">Book Name</th>
							<th scope="col">Author</th>
							<th scope="col">Genre</th>
							<th scope="col">Date Get</th>
							<th scope="col">status</th>
							<th scope="col">Option</th>
						</tr>
					</thead>

				<?php
				
				include "Connection.php";
				
				$records = mysqli_query($connect, "SELECT * FROM bookslist");
				
				while($data = mysqli_fetch_array($records))
				{
					?>
					<tr>
					<td><?php echo $data['bookid']; ?></td>
					<td><?php echo $data['bookname']; ?></td>
					<td><?php echo $data['author']; ?></td>
					<td><?php echo $data['genre']; ?></td>
					<td><?php echo $data['dateget']; ?></td>
					<td><?php echo $data['status']; ?></td>
					<td><div class="btn-group">
	    <a href="RemoveBook.php?id=<?php echo $data['bookid'];?>" class="refe">Remove</a>      
	</div>
	</td>
				</tr>
				<?php
				}
				?>
				</table>

			</div>