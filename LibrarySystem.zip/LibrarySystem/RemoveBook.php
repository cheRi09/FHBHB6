<?php 	
include 'Connection.php';
require_once 'Authentication.php';


$bookid = $_GET['id'];
$del = mysqli_query($connect,"DELETE FROM bookslist WHERE bookid=$bookid");

if($del)
{
	echo "<script>alert('SUCCESSFULLY DELETED')</script>";
	mysqli_close($connect);
	exit;
}
else
{
	echo "ERROR DELETING";
	
} // /if $_POST